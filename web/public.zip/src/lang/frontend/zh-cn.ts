/**
 * 前台公共语言包
 * 覆盖风险：请避免使用页面语言包的目录名、文件名作为翻译 key
 */
export default {
    Integral: '积分',
    Balance: '余额',
    Language: '语言',
    Copyright: '版权所有',
    'Member Center': '会员中心',
    'Logout login': '注销登录',
    'Member center disabled': '会员中心已禁用，请联系网站管理员开启。',
}
