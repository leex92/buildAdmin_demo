export default {
    'Steve Jobs': '伟大的艺术品不必追随潮流，他本身就能引领潮流。 -- 乔布斯',
}
