export default {
    'Change time': '变更时间',
    'Current points': '当前积分',
    'Points after change': '变更后积分',
    'Score change record': '积分变更记录',
}
