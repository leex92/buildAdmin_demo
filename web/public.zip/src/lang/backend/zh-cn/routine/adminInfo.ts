export default {
    'Last logged in on': '上次登录于',
    'user name': '用户名',
    'User nickname': '用户昵称',
    'Please enter a nickname': '请输入昵称',
    'e-mail address': '邮箱地址',
    'phone number': '手机号码',
    autograph: '签名',
    'This guy is lazy and doesn write anything': '这家伙很懒，什么也没写',
    'New password': '新密码',
    'Please leave blank if not modified': '不修改请留空',
    'Save changes': '保存修改',
    'Operation log': '操作日志',
}
