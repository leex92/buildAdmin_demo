export default {
    id: 'ID',
    table_name: '数据表名',
    table: '数据表数据',
    fields: '字段数据',
    status: '状态',
    'status delete': '已删除',
    'status success': '成功',
    'status error': '失败',
    'status start': '生成中',
    create_time: '创建时间',
    'quick Search Fields': 'ID、数据表名',
}
