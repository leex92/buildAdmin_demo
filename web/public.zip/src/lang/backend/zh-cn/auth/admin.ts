export default {
    username: '用户名',
    nickname: '昵称',
    grouping: '分组',
    'head portrait': '头像',
    mailbox: '邮箱',
    mobile: '手机号',
    'Last login': '最后登录',
    Password: '密码',
    'Please leave blank if not modified': '不修改请留空',
    'Personal signature': '个性签名',
    'Administrator login': '管理员登录名',
}
