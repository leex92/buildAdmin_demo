export default {
    'Last logged in on': 'Last logged on',
    'user name': 'Username',
    'User nickname': 'User nickname',
    'Please enter a nickname': 'Please enter a nickname',
    'e-mail address': 'E-mail address',
    'phone number': 'Mobile number',
    autograph: 'Signature',
    'This guy is lazy and doesn write anything': "This guy is lazy and didn't write anything.",
    'New password': 'New password',
    'Please leave blank if not modified': 'Please leave blank if you do not modify',
    'Save changes': 'Save changes',
    'Operation log': 'Operation log',
}
