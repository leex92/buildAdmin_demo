export default {
    'Please enter an account': 'Please enter your account',
    'Please input a password': 'Please enter your password',
    'Please enter the verification code': 'Please enter the Captcha',
    'Hold session': 'Keep the session',
    'Sign in': 'Sign in',
    'The verification code length must be between 4 and 6 bits': 'The Captcha length must be between 4 and 6 digit.',
}
