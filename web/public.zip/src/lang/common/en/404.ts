export default {
    'problems tip':
        'Your website has encountered some problems. The system is optimizing and reporting fault information. We will improve and reduce this situation in the future.',
    'We will automatically return to the previous page when we are finished': 'Auto return to previous page when finished.',
    'Return to home page': 'Back to Home',
    'Back to previous page': 'Back to previous page',
}
