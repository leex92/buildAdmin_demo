export default {
    'Please enter the correct mobile number': '请输入正确的手机号',
    'Please enter the correct account': '要求3到15位，字母开头且只含字母、数字、下划线',
    'Please enter the correct password': '密码要求6到32位，不能包含 & < > " \'',
    'Please enter the correct name': '请输入正确的名称',
    'Content cannot be empty': '内容不能为空',
    'Floating point number': '浮点数',
    required: '必填',
    'editor required': '富文本必填',
}
